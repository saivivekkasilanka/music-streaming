### Helper codes.
