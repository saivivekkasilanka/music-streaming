### Stored data.
